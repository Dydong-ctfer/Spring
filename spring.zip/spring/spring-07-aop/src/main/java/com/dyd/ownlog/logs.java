package com.dyd.ownlog;

public class logs {
    public void before(){
        System.out.println("before");
    }
    public void after(){
        System.out.println("after");
    }
}
