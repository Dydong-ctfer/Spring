package com.dyd.demo01;

public interface Rent {
    public void rent();
}
