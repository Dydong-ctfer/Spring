package com.dyd.pojo;

public class Cat {
    public void shout(){
        System.out.println("miao");
    }
}
