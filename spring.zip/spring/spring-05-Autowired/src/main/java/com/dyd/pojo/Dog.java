package com.dyd.pojo;

public class Dog {
    public void shout(){
        System.out.println("wang~");
    }
}
