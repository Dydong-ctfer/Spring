package com.dyd.pojo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class User {
    @Value("dyd")
    public String name;

    public void setName(String name) {
        this.name = name;
    }
}
