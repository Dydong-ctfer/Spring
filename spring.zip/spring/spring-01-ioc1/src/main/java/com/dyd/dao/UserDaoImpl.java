package com.dyd.dao;

public class UserDaoImpl implements UserDao{
    @Override
    public void getUser() {
        System.out.println("hello");
    }
}
