package com.dyd.service;

public interface UserService {
    void getUser();
}
