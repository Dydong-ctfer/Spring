package com.dyd.dao;

public class UserDaoIMysqlImpl implements UserDao{
    public void getUser()
    {
        System.out.println("mysql hello");
    }
}
