package com.dyd.dao;

public interface UserDao {
    void getUser();
}
